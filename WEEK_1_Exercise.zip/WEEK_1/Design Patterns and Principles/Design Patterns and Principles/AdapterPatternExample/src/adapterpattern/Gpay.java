package adapterpattern;

public class Gpay {
 public void makePayment(double amount) {
	 System.out.println("Processing payment of $" + amount + " through Gpay.");
 }
}

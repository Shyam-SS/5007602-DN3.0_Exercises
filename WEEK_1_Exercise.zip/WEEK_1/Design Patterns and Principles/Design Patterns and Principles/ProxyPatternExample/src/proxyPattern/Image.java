package proxyPattern;

public interface Image {
	void display();
}

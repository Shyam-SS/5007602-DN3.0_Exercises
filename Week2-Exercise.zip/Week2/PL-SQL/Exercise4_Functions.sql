-- Scenario 1
CREATE OR REPLACE FUNCTION CalculateAge(dob IN DATE) RETURN NUMBER
IS
    age NUMBER;
BEGIN
    age := EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM dob);
    RETURN AGE;
END;


ACCEPT dob CHAR PROMPT 'Enter the date of birth (YYYY-MM-DD): ';
SET SERVEROUTPUT ON;
DECLARE
    dob_input VARCHAR2(10) := '&dob';
    dob DATE;
    age NUMBER;
BEGIN
    dob := TO_DATE(dob_input, 'YYYY-MM-DD');
    age := CalculateAge(dob);
    DBMS_OUTPUT.PUT_LINE(age);
END;


--Scenario 2
CREATE OR REPLACE FUNCTION CalculateMonthlyInstallments(amount IN NUMBER, rate IN NUMBER, dur IN NUMBER) RETURN NUMBER
IS
    mi NUMBER;
    monthly_rate NUMBER;
BEGIN
    monthly_rate := rate / 12 / 100;
    mi := amount * ((monthly_rate * POWER(1 + monthly_rate, dur * 12)) / 
                    (POWER(1 + monthly_rate, dur * 12) - 1));
    RETURN mi;
END;

ACCEPT amount NUMBER PROMPT 'Enter Principal amount: ';
ACCEPT rate NUMBER PROMPT 'Enter rate: ';
ACCEPT duration NUMBER PROMPT 'Enter time: ';
SET SERVEROUTPUT ON;
DECLARE
    amount NUMBER := &amount;
    rate NUMBER(4,2) := &rate;
    dur NUMBER := &dur;
    EMI NUMBER(10,2);
BEGIN
    EMI := CalculateMonthlyInstallments(amount, rate, dur);
    DBMS_OUTPUT.PUT_LINE(EMI);
END;



--Scenario 3
CREATE OR REPLACE FUNCTION HasSufficientBalance(accid in NUMBER, amount in NUMBER) RETURN BOOLEAN
IS 
    bal NUMBER;
BEGIN
    SELECT BALANCE INTO bal FROM ACCOUNTS WHERE ACCOUNTID = accid;
    IF amount <= bal THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
END;

SET SERVEROUTPUT ON;
DECLARE
    accid NUMBER := &accid;
    amt NUMBER := &amt;
    Checkcriteria BOOLEAN;
BEGIN
    Checkcriteria := HasSufficientBalance(accid, amt);
    DBMS_OUTPUT.PUT_LINE(CASE WHEN Checkcriteria THEN 'TRUE' ELSE 'FALSE' END);
END;
